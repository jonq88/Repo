import arcpy
import xml.dom.minidom as DOM 
import os

#check of cached or web capabilities				
def hosted(Name):
	configProps = doc.getElementsByTagName(Name)[0]
	propArray = configProps.firstChild
	propSets = propArray.childNodes
	for propSet in propSets:
		keyValues = propSet.childNodes
		for keyValue in keyValues:
			if keyValue.tagName == 'Key':
				if keyValue.firstChild.data == "WebCapabilities":
					# turn on caching
					keyValue.nextSibling.firstChild.data = "Query,Create,Update,Delete,Uploads,Editing"
				if keyValue.firstChild.data == "isCached":
					# turn on caching
					keyValue.nextSibling.firstChild.data = "false"

					
#enable access
def capability(capability, typeName):
	extension = typeName.parentNode
	for extElement in extension.childNodes:
		# Disabled SOE.
		if extElement.tagName == 'Enabled':
			print extElement.firstChild.data
			extElement.firstChild.data = 'true'
			arcpy.AddMessage("Enabled " + capability)
 
# define local variables

agsFile = arcpy.GetParameterAsText(0)
service = arcpy.GetParameterAsText(1)
mapDoc = arcpy.GetParameterAsText(2)
hosted = arcpy.GetParameter(3)
workspace  = os.path.join(r'C:/Staging',agsFile[:-3])
if not os.path.exists(workspace):
  arcpy.CreateFolder_management(workspace)
sddraft = os.path.join(workspace,(service + 'orig.sddraft'))
sd = os.path.join(workspace,(service + '.sd'))
if hosted == 1:
	con = 'My Hosted Services'
	if mapDoc == "":
		mxd = arcpy.mapping.MapDocument("Current")
		mxd.saveACopy(os.path.join(workspace,service+".mxd"))
		mapDoc = os.path.join(workspace,service+".mxd")
	else:
		service = os.path.basename(mapDoc)[:-4].replace(" ", "_")
	arcpy.AddMessage("Acquired MXD")
	arcpy.mapping.CreateMapSDDraft(mapDoc, sddraft, service, 'MY_HOSTED_SERVICES',"","","","Test","Test")
	arcpy.AddMessage("Created SDDraft")
	doc = DOM.parse(sddraft)
	typeNames = doc.getElementsByTagName('TypeName')
	for typeName in typeNames:
		# Get the TypeName we want to disable.
		if typeName.firstChild.data == "MapServer":
			typeName.firstChild.data = "FeatureServer"

	arcpy.AddMessage("Updating SDDraft")
	hosted('Info')
	hosted('ConfigurationProperties')

else:
	instances = arcpy.GetParameterAsText(4)
	if instances == "":
		instances = "1"
	if mapDoc == "":
		mxd = arcpy.mapping.MapDocument("Current")
		mxd.saveACopy(os.path.join(workspace,service+".mxd"))
		mapDoc = os.path.join(workspace,service+".mxd")
	else:
		service = os.path.basename(mapDoc)[:-4].replace(" ", "_")
	arcpy.AddMessage("Acquired mxd")
	sd = os.path.join(workspace,(service + '.sd'))
	print "Creating SDDraft"
	arcpy.AddMessage("Creating SDDraft")
	con = 'GIS Servers/' + agsFile
	arcpy.mapping.CreateMapSDDraft(mapDoc, sddraft, service, 'ARCGIS_SERVER', con, "false", None)
	print "Created SDDraft"
	arcpy.AddMessage("Created SDDraft")
	# read sddraft xml
	doc = DOM.parse(sddraft)
	#Update service properties
	keys = doc.getElementsByTagName('Key')
	for key in keys:
		if key.hasChildNodes():
			if key.firstChild.data == 'MinInstances':
				key.nextSibling.firstChild.data = instances
	boolean1 = arcpy.GetParameter(5)
	boolean2 = arcpy.GetParameter(6)
	boolean3 = arcpy.GetParameter(7)
	boolean4 = arcpy.GetParameter(8)
	boolean5 = arcpy.GetParameter(9)
	
	typeNames = doc.getElementsByTagName('TypeName')
	for typeName in typeNames:
		#enable feature access
		if boolean1 == 1:
			if typeName.firstChild.data == 'FeatureServer':
				capability("Feature Access", typeName)
			
		#enable mobile server
		if boolean2 == 1:
			if typeName.firstChild.data == 'MobileServer':
				capability("Mobile capability", typeName)
					
		#enable NA server
		if boolean3 == 1:
			if typeName.firstChild.data == 'NAServer':
				capability("Network Analyst", typeName)
		
		#enable WMS Server
		if boolean4 == 1:
			if typeName.firstChild.data == 'WMSServer':
				capability("Enabled WMS Capability", typeName)
					
		#enable WCS server			
		if boolean5 == 1:
			if typeName.firstChild.data == 'WCSServer':
				capability("Enabled WCS Capability", typeName)



	
# output to a new sddraft
outXml = os.path.join(workspace,service + ".sddraft")
f = open(outXml, 'w')     
doc.writexml( f )     
f.close() 
	
analysis = arcpy.mapping.AnalyzeForSD(outXml)
if analysis['errors'] == {}:
	# Execute StageService
	arcpy.StageService_server(outXml, sd)
	arcpy.AddMessage("Created SD file")
	# Execute UploadServiceDefinition
	arcpy.UploadServiceDefinition_server(sd, con)
	arcpy.AddMessage("Created service")
		
else: 
	# if the sddraft analysis contained errors, display them
	for key in ('messages', 'warnings', 'errors'):
		if key == ('errors'):
			arcpy.AddError("----" + key.upper() + "---")
			vars = analysis[key]
			for ((message, code), layerlist) in vars.iteritems():
				arcpy.AddError("Error code " + str(code) + ": " + str(message))
			arcpy.AddError("----" + key.upper() + "---")
			# print "    ", message, " (CODE %i)" % code
			# print "       applies to:",
			# for layer in layerlist:
				# print layer.name,
		if key == ('warnings'):
			arcpy.AddWarning("----" + key.upper() + "---")
			vars = analysis[key]
			for ((message, code), layerlist) in vars.iteritems():
				arcpy.AddWarning("Error code " + str(code) + ": " + str(message))
			arcpy.AddWarning("----" + key.upper() + "---")
			# print
if arcpy.Exists(os.path.join(workspace,"Publish.mxd")):
	arcpy.Delete_management(os.path.join(workspace,"Publish.mxd"))
arcpy.Delete_management(sd)
arcpy.Delete_management(sddraft)
